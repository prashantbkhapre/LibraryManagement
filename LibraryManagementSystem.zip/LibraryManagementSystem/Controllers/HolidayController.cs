﻿using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;

namespace LibraryManagementSystem.Controllers
{
    public class HolidayController : Controller
    {
        // GET: HolidayController
        public ActionResult Index()
        {
            List<BankHoliday> list = new List<BankHoliday>();
            return View(list);
        }

        // GET: HolidayController/Details/5
        public ActionResult Details(int id)
        {
            return View();
        }

        // GET: HolidayController/Create
        public ActionResult Create()
        {
            return View();
        }

        // POST: HolidayController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: HolidayController/Edit/5
        public ActionResult Edit(int id)
        {
            return View();
        }

        // POST: HolidayController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: HolidayController/Delete/5
        public ActionResult Delete(int id)
        {
            return View();
        }

        // POST: HolidayController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }
    }
}
