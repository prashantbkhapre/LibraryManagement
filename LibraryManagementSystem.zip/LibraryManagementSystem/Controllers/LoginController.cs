﻿using LibraryManagementSystem.Models;
using Microsoft.AspNetCore.Mvc;

namespace LibraryManagementSystem.Controllers
{
    public class LoginController : Controller
    {
        public IActionResult Login()
        {
            return View();
        }


        [HttpPost]
        public IActionResult Login(Login model)
        {
            if (ModelState.IsValid)
            {

                if ((model.Username == "librarian@veripark.test" || model.Username == "supervisor@veripark.test") && model.Password == " Password1$")
                {
                    return RedirectToAction("Index", "Home");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid username or password.");
                }

            }
            return View();
        }        
    }
}
