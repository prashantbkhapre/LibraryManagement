﻿namespace LibraryManagementSystem.Models
{
    public class Customers
    {
        public string? Name { get; set; }
        public string? Address { get; set; }
        public string? Contact { get; set; }
        public int NationalID { get; set; }
    }
}
