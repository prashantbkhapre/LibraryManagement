﻿namespace LibraryManagementSystem.Models
{
    public class BankHoliday
    {
        public string? HolidayOccasion { get; set; }
        public DateTime? FromDate { get; set; }
        public DateTime? ToDate { get; set; }
        public bool Active { get; set; } = true;

    }
}
