﻿namespace LibraryManagementSystem.Models
{
    public class Books
    {
        public string? Title { get; set; }
        public string? ISBN { get; set; }
        public string? Auther { get; set; }
        public string? Publisher { get; set; }
    }
}
