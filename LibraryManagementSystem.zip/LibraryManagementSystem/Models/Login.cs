﻿using System.ComponentModel.DataAnnotations;

namespace LibraryManagementSystem.Models
{
    public class Login
    {
        [Key]
        public int userId { get; set; }

        [Required(ErrorMessage = "Username is requried!")]
        public string Username { get; set; }

        [Required(ErrorMessage = "Password is requried!")]
        public string Password { get; set; }
    }
}
